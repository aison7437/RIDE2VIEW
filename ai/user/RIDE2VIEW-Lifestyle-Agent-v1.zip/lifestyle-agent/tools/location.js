function normalizeLocation(value) {
  if (!value) return null;

  const text = String(value).trim().toLowerCase();

  const aliases = {
    nairobi: "Nairobi",
    westlands: "Westlands",
    kilimani: "Kilimani",
    "south b": "South B",
    "south c": "South C",
    kasarani: "Kasarani",
    ruaka: "Ruaka",
    mombasa: "Mombasa",
    kisumu: "Kisumu"
  };

  return aliases[text] || (
    text.charAt(0).toUpperCase() + text.slice(1)
  );
}

function extractLocation(searchText = "") {
  const text = String(searchText).toLowerCase();

  const locations = [
    "westlands",
    "kilimani",
    "south b",
    "south c",
    "kasarani",
    "ruaka",
    "nairobi",
    "mombasa",
    "kisumu"
  ];

  const found = locations.find(location => text.includes(location));
  return found ? normalizeLocation(found) : null;
}

function extractCity(searchText = "") {
  const text = String(searchText).toLowerCase();

  if (text.includes("nairobi")) return "Nairobi";
  if (text.includes("mombasa")) return "Mombasa";
  if (text.includes("kisumu")) return "Kisumu";

  return null;
}

module.exports = {
  normalizeLocation,
  extractLocation,
  extractCity
};
