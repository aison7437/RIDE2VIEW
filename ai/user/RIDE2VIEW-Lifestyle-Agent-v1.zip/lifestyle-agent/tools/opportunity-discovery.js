const { extractLocation, extractCity, normalizeLocation } = require("./location");

const PROPERTY_DATA = [
  {
    id: "p1",
    type: "property",
    category: "residential",
    title: "Affordable 1 Bedroom Apartment",
    location: "Nairobi",
    neighborhood: "Kasarani",
    city: "Nairobi",
    bedrooms: 1,
    price: 18000,
    rent: 18000,
    currency: "KSH",
    studentFriendly: true,
    premium: false,
    viewingMinutes: 45,
    description: "Affordable residential apartment suitable for budget-conscious residents and students."
  },
  {
    id: "p2",
    type: "property",
    category: "residential",
    title: "Modern 2 Bedroom Apartment",
    location: "Nairobi",
    neighborhood: "Kilimani",
    city: "Nairobi",
    bedrooms: 2,
    price: 35000,
    rent: 35000,
    currency: "KSH",
    studentFriendly: false,
    premium: false,
    viewingMinutes: 50,
    description: "Modern apartment with convenient access to Nairobi amenities."
  },
  {
    id: "p3",
    type: "property",
    category: "residential",
    title: "Spacious 3 Bedroom Apartment",
    location: "Nairobi",
    neighborhood: "Kilimani",
    city: "Nairobi",
    bedrooms: 3,
    price: 55000,
    rent: 55000,
    currency: "KSH",
    studentFriendly: false,
    premium: false,
    viewingMinutes: 55,
    description: "Spacious three-bedroom property suited to families and professionals."
  },
  {
    id: "p4",
    type: "property",
    category: "residential",
    title: "Westlands Executive Apartment",
    location: "Nairobi",
    neighborhood: "Westlands",
    city: "Nairobi",
    bedrooms: 2,
    price: 70000,
    rent: 70000,
    currency: "KSH",
    studentFriendly: false,
    premium: true,
    viewingMinutes: 40,
    description: "Executive Westlands residence with premium positioning."
  },
  {
    id: "p5",
    type: "property",
    category: "residential",
    title: "Luxury Runda Villa",
    location: "Nairobi",
    neighborhood: "Runda",
    city: "Nairobi",
    bedrooms: 5,
    price: 250000,
    rent: 250000,
    currency: "KSH",
    studentFriendly: false,
    premium: true,
    viewingMinutes: 60,
    description: "High-end luxury villa for premium residential requirements."
  },
  {
    id: "p6",
    type: "property",
    category: "student-housing",
    title: "Student Studio Residence",
    location: "Nairobi",
    neighborhood: "Kasarani",
    city: "Nairobi",
    bedrooms: 1,
    price: 12000,
    rent: 12000,
    currency: "KSH",
    studentFriendly: true,
    premium: false,
    viewingMinutes: 35,
    description: "Budget-oriented student accommodation."
  }
];

const MOBILITY_DATA = [
  {
    id: "m1",
    type: "mobility",
    category: "transport",
    title: "General Ride",
    location: "Nairobi",
    service: "General",
    price: 650,
    currency: "KSH",
    durationMinutes: 10,
    womenOnly: false,
    description: "General Ride2View transport service."
  },
  {
    id: "m2",
    type: "mobility",
    category: "transport",
    title: "Women-Only Ride",
    location: "Nairobi",
    service: "Women-Only",
    price: 750,
    currency: "KSH",
    durationMinutes: 25,
    womenOnly: true,
    description: "Women-only transport option."
  },
  {
    id: "m3",
    type: "mobility",
    category: "transport",
    title: "Student Ride",
    location: "Nairobi",
    service: "Students",
    price: 450,
    currency: "KSH",
    durationMinutes: 15,
    studentFriendly: true,
    womenOnly: false,
    description: "Student-oriented transport option."
  },
  {
    id: "m4",
    type: "mobility",
    category: "transport",
    title: "VIP Ride",
    location: "Nairobi",
    service: "VIP",
    price: 2000,
    currency: "KSH",
    durationMinutes: 60,
    premium: true,
    womenOnly: false,
    description: "Premium transport service."
  }
];

function parseBudget(text) {
  const match = String(text).toLowerCase().match(
    /(?:ksh|kes|budget(?:\s+of)?)[^\d]{0,10}(\d[\d,]*)/
  );
  if (!match) return null;
  return Number(match[1].replace(/,/g, ""));
}

function parseBedrooms(text) {
  const match = String(text).toLowerCase().match(
    /(\d+)\s*[- ]?\s*bed(?:room|rooms)?\b/
  );
  return match ? Number(match[1]) : null;
}

function parseIntent(searchText = "") {
  const text = String(searchText).toLowerCase();

  return {
    wantsStudent: /\bstudent|student accommodation|student housing\b/.test(text),
    wantsPremium: /\bpremium|luxury|executive|high[- ]end\b/.test(text),
    wantsWomenOnly: /\bwomen[- ]only|women only\b/.test(text),
    wantsMobility: /\btransport|ride|mobility|get there|take me|help me get there\b/.test(text),
    wantsProperty: /\bproperty|house|home|apartment|accommodation|villa\b/.test(text),
    wantsAffordable: /\baffordable|cheapest|most affordable|budget\b/.test(text),
    bedrooms: parseBedrooms(text),
    budget: parseBudget(text),
    maxViewingTime: /\bone hour|60 minutes|within 1 hour|within one hour\b/.test(text) ? 60 : null,
    neighborhood: extractLocation(text) && extractLocation(text) !== "Nairobi"
      ? extractLocation(text)
      : null
  };
}

function matchesProperty(property, intent) {
  if (intent.neighborhood &&
      property.neighborhood.toLowerCase() !== intent.neighborhood.toLowerCase()) {
    return false;
  }

  if (intent.bedrooms !== null && property.bedrooms !== intent.bedrooms) {
    return false;
  }

  if (intent.wantsStudent && !property.studentFriendly) {
    return false;
  }

  if (intent.wantsPremium && !property.premium) {
    return false;
  }

  if (intent.maxViewingTime !== null &&
      property.viewingMinutes > intent.maxViewingTime) {
    return false;
  }

  return true;
}

function matchesMobility(ride, intent) {
  if (intent.wantsWomenOnly && !ride.womenOnly) return false;
  if (intent.wantsStudent && ride.service !== "Students") return false;
  if (intent.wantsPremium && !ride.premium) return false;
  return true;
}

function discoverOpportunities(context = {}) {
  const searchText =
    context.searchText ||
    context.query ||
    context.userRequest ||
    "";

  const intent = parseIntent(searchText);

  const city =
    normalizeLocation(context.location) ||
    extractCity(searchText) ||
    "Nairobi";

  let properties = PROPERTY_DATA.filter(
    property =>
      property.location.toLowerCase() === city.toLowerCase() &&
      matchesProperty(property, intent)
  );

  const mobility = intent.wantsMobility
    ? MOBILITY_DATA.filter(
        ride =>
          ride.location.toLowerCase() === city.toLowerCase() &&
          matchesMobility(ride, intent)
      )
    : [];

  /*
   * For an affordability/budget request, retain all suitable
   * properties when strict budget filtering would produce zero.
   * Reasoning/scoring will identify alternatives.
   */
  if (
    properties.length === 0 &&
    intent.wantsProperty &&
    (intent.budget !== null || intent.wantsAffordable)
  ) {
    properties = PROPERTY_DATA.filter(
      property =>
        property.location.toLowerCase() === city.toLowerCase() &&
        (!intent.neighborhood ||
          property.neighborhood.toLowerCase() === intent.neighborhood.toLowerCase()) &&
        (!intent.bedrooms || property.bedrooms === intent.bedrooms)
    );
  }

  const opportunities = [...properties, ...mobility];

  console.log("[Lifestyle Discovery] Search text:", searchText);
  console.log("[Lifestyle Discovery] Intent:", intent);
  console.log("[Lifestyle Discovery] Properties:", properties.length);
  console.log("[Lifestyle Discovery] Mobility:", mobility.length);
  console.log("[Lifestyle Discovery] Total:", opportunities.length);

  return {
    success: true,
    intent,
    location: city,
    properties,
    mobility,
    opportunities,
    count: opportunities.length
  };
}

module.exports = {
  discoverOpportunities,
  parseIntent,
  PROPERTY_DATA,
  MOBILITY_DATA
};
