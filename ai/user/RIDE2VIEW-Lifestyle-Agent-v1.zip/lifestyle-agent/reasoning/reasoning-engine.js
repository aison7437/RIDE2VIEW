function normalizeOpportunity(item) {
  return item && typeof item === "object" ? item : null;
}

function reasonAboutOpportunities(context = {}, opportunities = []) {
  const intent = context.intent || {};
  const list = Array.isArray(opportunities) ? opportunities : [];

  return list
    .map(normalizeOpportunity)
    .filter(Boolean)
    .map(item => {
      const reasons = [];
      let intentScore = 0;

      if (item.type === "property") {
        if (intent.wantsProperty) {
          intentScore += 40;
          reasons.push("Matches the property requirement.");
        }

        if (intent.bedrooms !== null &&
            intent.bedrooms !== undefined &&
            item.bedrooms === intent.bedrooms) {
          intentScore += 25;
          reasons.push("Matches requested bedroom count.");
        }

        if (intent.neighborhood &&
            String(item.neighborhood).toLowerCase() ===
            String(intent.neighborhood).toLowerCase()) {
          intentScore += 25;
          reasons.push("Matches requested neighborhood.");
        }

        if (intent.wantsStudent && item.studentFriendly) {
          intentScore += 25;
          reasons.push("Suitable for student accommodation.");
        }

        if (intent.wantsPremium && item.premium) {
          intentScore += 25;
          reasons.push("Matches premium/luxury preference.");
        }

        if (intent.wantsAffordable) {
          reasons.push("Evaluated for affordability.");
        }

        if (intent.maxViewingTime !== null &&
            item.viewingMinutes <= intent.maxViewingTime) {
          intentScore += 15;
          reasons.push("Meets the viewing-time constraint.");
        }

        if (intent.budget !== null &&
            Number(item.price) <= Number(intent.budget)) {
          intentScore += 20;
          reasons.push("Within the requested budget.");
        }

        if (intent.budget !== null &&
            Number(item.price) > Number(intent.budget)) {
          reasons.push("Above budget; retained as a possible alternative.");
        }
      }

      if (item.type === "mobility") {
        if (intent.wantsMobility) {
          intentScore += 40;
          reasons.push("Matches the transport requirement.");
        }

        if (intent.wantsWomenOnly && item.womenOnly) {
          intentScore += 40;
          reasons.push("Matches women-only transport requirement.");
        }

        if (intent.wantsStudent && item.studentFriendly) {
          intentScore += 30;
          reasons.push("Matches student transport requirement.");
        }

        if (intent.wantsPremium && item.premium) {
          intentScore += 30;
          reasons.push("Matches premium transport requirement.");
        }
      }

      return {
        ...item,
        reasoning: {
          intentScore,
          reasons,
          rationale: reasons.length
            ? reasons.join(" ")
            : "Potentially relevant opportunity."
        }
      };
    });
}

module.exports = {
  reasonAboutOpportunities
};
