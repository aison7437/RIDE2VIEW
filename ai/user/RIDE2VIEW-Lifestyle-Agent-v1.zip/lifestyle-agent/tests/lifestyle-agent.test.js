const {
  generateLifestyleRecommendations
} = require("../workflows/recommendation");

const scenarios = [
  {
    name: "Baseline Nairobi property search",
    query: "i want to find a suitable property in nairobi.",
    checks: result =>
      hasProperty(result, "Nairobi")
  },
  {
    name: "Three bedroom property",
    query: "find me a 3 bedroom property in nairobi.",
    checks: result =>
      hasProperty(result, "Nairobi") &&
      result.recommendations.some(r => r.bedrooms === 3)
  },
  {
    name: "Budget optimization",
    query: "find me the most affordable suitable property in nairobi.",
    checks: result =>
      hasProperty(result, "Nairobi") &&
      result.recommendations.some(r => r.type === "property")
  },
  {
    name: "Westlands property",
    query: "find me a property in westlands.",
    checks: result =>
      result.recommendations.some(
        r =>
          r.type === "property" &&
          String(r.neighborhood).toLowerCase() === "westlands"
      )
  },
  {
    name: "Property plus transportation",
    query: "find me a suitable property in nairobi and help me get there.",
    checks: result =>
      hasProperty(result, "Nairobi") &&
      result.recommendations.some(r => r.type === "mobility")
  },
  {
    name: "One hour viewing",
    query: "i need to find a property i can view within one hour.",
    checks: result =>
      hasProperty(result, "Nairobi") &&
      result.recommendations.some(
        r =>
          r.type === "property" &&
          Number(r.viewingMinutes) <= 60
      )
  },
  {
    name: "Women only mobility",
    query: "find me a property in nairobi and suitable women-only transport.",
    checks: result =>
      hasProperty(result, "Nairobi") &&
      result.recommendations.some(
        r => r.type === "mobility" && r.womenOnly === true
      )
  },
  {
    name: "Student housing",
    query: "find affordable student accommodation in nairobi.",
    checks: result =>
      result.recommendations.some(
        r => r.type === "property" && r.studentFriendly === true
      )
  },
  {
    name: "Premium property",
    query: "find me a premium luxury property in nairobi.",
    checks: result =>
      result.recommendations.some(
        r => r.type === "property" && r.premium === true
      )
  },
  {
    name: "Budget failure / alternatives",
    query: "find me a suitable property in nairobi for ksh 10000.",
    checks: result =>
      result.recommendations.some(
        r => r.type === "property" && Number(r.price) > 10000
      ) &&
      result.budgetAnalysis.alternativesAvailable === true
  }
];

function hasProperty(result, location) {
  return result.recommendations.some(
    r =>
      r.type === "property" &&
      String(r.location).toLowerCase() === location.toLowerCase()
  );
}

let passed = 0;

console.log("==============================================");
console.log("RIDE2VIEW LIFESTYLE AGENT SCENARIO TEST SUITE");
console.log("==============================================");

for (const [index, scenario] of scenarios.entries()) {
  console.log(`\n==================================================`);
  console.log(`SCENARIO ${index + 1}: ${scenario.name}`);
  console.log(`==================================================`);

  const result =
    generateLifestyleRecommendations({
      searchText: scenario.query
    });

  const errors = [];

  if (!result.success) {
    errors.push("Agent did not complete successfully.");
  }

  if (!Array.isArray(result.recommendations)) {
    errors.push("recommendations must be an array.");
  }

  if (!result.nextAction ||
      typeof result.nextAction.action !== "string") {
    errors.push("nextAction.action must be a string.");
  }

  if (!result.nextAction ||
      typeof result.nextAction.label !== "string") {
    errors.push("nextAction.label must be a string.");
  }

  if (result.recommendations.length === 0) {
    errors.push("No recommendations returned.");
  }

  try {
    if (!scenario.checks(result)) {
      errors.push("Scenario-specific requirement failed.");
    }
  } catch (error) {
    errors.push(`Scenario check failed: ${error.message}`);
  }

  if (errors.length === 0) {
    passed++;
    console.log("STATUS: PASS");
  } else {
    console.log("STATUS: FAIL");
    for (const error of errors) {
      console.log(`  ✗ ${error}`);
    }
  }
}

const total = scenarios.length;
const failed = total - passed;
const rate = ((passed / total) * 100).toFixed(1);

console.log("\n==============================================");
console.log("FINAL TEST SUMMARY");
console.log("==============================================");
console.log(`TOTAL: ${total}`);
console.log(`PASSED: ${passed}`);
console.log(`FAILED: ${failed}`);
console.log(`PASS RATE: ${rate}%`);
console.log("==============================================");

if (failed > 0) {
  process.exitCode = 1;
}
