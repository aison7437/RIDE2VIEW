# Lifestyle Agent Architecture

## Contract

Every pipeline stage receives an array of normalized opportunity objects and returns an array of opportunity objects.

### Opportunity types

- `property`
- `mobility`

### Required stable fields

- `id`
- `type`
- `title`
- `location`
- `category`

Optional domain fields remain available.

## Pipeline

1. Discovery
2. Reasoning
3. Scoring
4. Ranking
5. Formatting

## Failure philosophy

A stage must not silently erase valid upstream data. Discovery retains alternatives when strict budget filtering would produce zero results, allowing the scoring/ranking layer to distinguish a hard match from a budget alternative.

## Extension path

Future adapters can replace:
- deterministic reasoning with an LLM
- static discovery with live property APIs
- static mobility data with dispatch APIs
- local scoring with learned utility models

The final result contract should remain stable.
