const {
  generateLifestyleRecommendations
} = require("./workflows/recommendation");

function runLifestyleAgent(input = {}) {
  return generateLifestyleRecommendations(input);
}

module.exports = {
  runLifestyleAgent,
  generateLifestyleRecommendations
};
