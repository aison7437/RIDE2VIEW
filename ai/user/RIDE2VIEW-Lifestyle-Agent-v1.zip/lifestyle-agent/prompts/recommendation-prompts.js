module.exports = {
  system:
    "Recommend Ride2View lifestyle opportunities using explicit user constraints, utility, and explainable reasoning.",

  recommendation:
    "Rank opportunities by suitability, constraint satisfaction, affordability, and user intent."
};
