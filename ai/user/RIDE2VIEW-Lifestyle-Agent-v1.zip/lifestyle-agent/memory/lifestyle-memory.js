function createMemory() {
  return {
    preferences: {},
    history: [],
    updatedAt: new Date().toISOString()
  };
}

function remember(memory, event) {
  const next = memory || createMemory();

  next.history.push({
    ...event,
    timestamp: new Date().toISOString()
  });

  next.updatedAt = new Date().toISOString();
  return next;
}

module.exports = {
  createMemory,
  remember
};
