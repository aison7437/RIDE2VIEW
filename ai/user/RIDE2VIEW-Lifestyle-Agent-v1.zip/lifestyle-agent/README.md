# Ride2View Lifestyle Agent v1

A deterministic, testable recommendation engine for Ride2View.

Pipeline:
User Request → Context Normalization → Discovery → Reasoning → Scoring → Ranking → Formatting → Final Response

Design principles:
- Stable contracts between every stage
- No silent conversion of valid opportunities to []
- Property and mobility opportunities share one normalized opportunity schema
- Constraint-aware reasoning
- Utility scoring is explainable
- Deterministic ranking
- Safe fallbacks
- No external dependencies

## Run

From this directory:

```bash
node tests/lifestyle-agent.test.js
```

Or from the repository root:

```bash
node ai/user/lifestyle-agent/tests/lifestyle-agent.test.js
```

## Integration

```js
const {
  generateLifestyleRecommendations
} = require("./workflows/recommendation");

const result = generateLifestyleRecommendations({
  searchText: "find me a 3 bedroom property in Nairobi"
});

console.log(result);
```

The package is deliberately deterministic in v1. An LLM/model adapter can be introduced later without changing the public result contract.
