function formatOne(item, index) {
  const isProperty = item.type === "property";
  const isMobility = item.type === "mobility";

  return {
    rank: index + 1,
    id: item.id,
    type: item.type,
    title: item.title,
    category: item.category,
    location: item.location,
    neighborhood: item.neighborhood || null,
    price: item.price ?? null,
    currency: item.currency || "KSH",
    bedrooms: item.bedrooms ?? null,
    service: item.service || null,
    viewingMinutes: item.viewingMinutes ?? null,
    durationMinutes: item.durationMinutes ?? null,
    womenOnly: item.womenOnly ?? false,
    studentFriendly: item.studentFriendly ?? false,
    premium: item.premium ?? false,
    score: item.score ?? 0,
    reason:
      item.reasoning?.rationale ||
      "Recommended based on your request.",
    description: item.description || null,
    kind: isProperty ? "property" : isMobility ? "mobility" : "opportunity"
  };
}

function formatRecommendations(opportunities = [], context = {}) {
  const max =
    Number(context.maxRecommendations) > 0
      ? Number(context.maxRecommendations)
      : 5;

  return (Array.isArray(opportunities) ? opportunities : [])
    .slice(0, max)
    .map(formatOne);
}

module.exports = {
  formatRecommendations
};
