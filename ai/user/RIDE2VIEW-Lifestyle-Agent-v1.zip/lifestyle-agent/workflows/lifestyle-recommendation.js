const {
  generateLifestyleRecommendations
} = require("./recommendation");

module.exports = {
  generateLifestyleRecommendations
};
