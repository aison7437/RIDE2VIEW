const {
  discoverOpportunities
} = require("../tools/opportunity-discovery");

const {
  reasonAboutOpportunities
} = require("../reasoning/reasoning-engine");

const {
  scoreOpportunities,
  rankOpportunities
} = require("../models/opportunity-scoring");

const {
  formatRecommendations
} = require("../recommendation/recommendation-formatter");

const CONFIG = require("../configs/lifestyle-config");

function asArray(value) {
  if (Array.isArray(value)) return value;
  if (!value || typeof value !== "object") return [];

  if (Array.isArray(value.opportunities)) {
    return value.opportunities;
  }

  const properties = Array.isArray(value.properties)
    ? value.properties
    : [];

  const mobility = Array.isArray(value.mobility)
    ? value.mobility
    : [];

  return [...properties, ...mobility];
}

function normalizeContext(input = {}) {
  const searchText =
    input.searchText ||
    input.query ||
    input.userRequest ||
    "";

  const rawDiscovery = discoverOpportunities({
    ...input,
    searchText
  });

  const intent = rawDiscovery.intent || {};

  return {
    ...input,
    searchText,
    location:
      input.location ||
      rawDiscovery.location ||
      CONFIG.defaults.location,
    intent,
    budget:
      input.budget ??
      intent.budget ??
      null,
    userBudget:
      input.userBudget ??
      intent.budget ??
      null,
    maxRecommendations:
      input.maxRecommendations ||
      CONFIG.ranking.maxRecommendations,
    _discovery: rawDiscovery
  };
}

function buildNextAction(primary, count) {
  if (primary && count > 0) {
    return {
      action: "review_primary_recommendation",
      label: "Review primary recommendation"
    };
  }

  return {
    action: "adjust_search_criteria",
    label: "Adjust search criteria and try again"
  };
}

function budgetAnalysis(context, recommendations) {
  const requestedBudget =
    context.budget ??
    context.userBudget ??
    context.intent?.budget ??
    null;

  const numericBudget = Number(requestedBudget);

  const priced =
    recommendations.filter(
      item =>
        item.price !== null &&
        item.price !== undefined &&
        Number.isFinite(Number(item.price))
    );

  return {
    requestedBudget,
    hasBudgetConstraint: Number.isFinite(numericBudget),
    alternativesAvailable: priced.length > 0,
    pricedAlternatives: priced.length
  };
}

function generateLifestyleRecommendations(input = {}) {
  console.log("[Lifestyle Recommendation] Starting workflow.");

  let context;

  try {
    context = normalizeContext(input);
  } catch (error) {
    return {
      success: false,
      agent: CONFIG.agentName,
      context: input,
      error: error.message,
      recommendations: [],
      count: 0,
      primary: null,
      nextAction: buildNextAction(null, 0),
      timestamp: new Date().toISOString()
    };
  }

  const rawDiscovery = context._discovery;
  const discovered = asArray(rawDiscovery);

  const discovery = {
    success: true,
    opportunities: discovered,
    count: discovered.length,
    intent: context.intent,
    location: context.location
  };

  console.log(
    `[Lifestyle Recommendation] Discovery complete: ${discovery.count}`
  );

  const reasoningOpportunities =
    reasonAboutOpportunities(context, discovered);

  const reasoning = {
    success: true,
    enabled: true,
    status: "completed",
    opportunities: reasoningOpportunities,
    count: reasoningOpportunities.length
  };

  console.log(
    `[Lifestyle Recommendation] Reasoning complete: ${reasoning.count}`
  );

  const scored =
    scoreOpportunities(reasoningOpportunities, context);

  const scoring = {
    success: true,
    opportunities: scored,
    count: scored.length
  };

  console.log(
    `[Lifestyle Recommendation] Scoring complete: ${scoring.count}`
  );

  const ranked =
    rankOpportunities(scored, context);

  const ranking = {
    success: true,
    opportunities: ranked,
    count: ranked.length
  };

  console.log(
    `[Lifestyle Recommendation] Ranking complete: ${ranking.count}`
  );

  let recommendations =
    formatRecommendations(ranked, context);

  if (recommendations.length === 0 && ranked.length > 0) {
    recommendations = ranked.slice(0, context.maxRecommendations);
  }

  console.log(
    `[Lifestyle Recommendation] Formatting complete: ${recommendations.length}`
  );

  const primary =
    recommendations.length > 0
      ? recommendations[0]
      : null;

  const result = {
    success: true,
    agent: CONFIG.agentName,
    version: CONFIG.version,
    context: {
      searchText: context.searchText,
      location: context.location,
      intent: context.intent
    },
    discovery,
    reasoning,
    scoring,
    ranking,
    recommendations,
    count: recommendations.length,
    primary,
    budgetAnalysis: budgetAnalysis(context, recommendations),
    summary:
      recommendations.length > 0
        ? "Lifestyle recommendations generated successfully."
        : "No suitable lifestyle recommendations were found.",
    nextAction: buildNextAction(primary, recommendations.length),
    timestamp: new Date().toISOString()
  };

  console.log(
    "[Lifestyle Recommendation] Workflow complete:",
    {
      discovery: result.discovery.count,
      reasoning: result.reasoning.count,
      scoring: result.scoring.count,
      ranking: result.ranking.count,
      formatting: result.recommendations.length,
      recommendations: result.count
    }
  );

  return result;
}

module.exports = {
  generateLifestyleRecommendations
};
