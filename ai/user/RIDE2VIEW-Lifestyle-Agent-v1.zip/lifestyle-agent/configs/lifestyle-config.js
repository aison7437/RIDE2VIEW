module.exports = {
  agentName: "ride2view-lifestyle-agent",
  version: "1.0.0",

  ranking: {
    maxRecommendations: 5,
    scoreWeights: {
      intentMatch: 0.35,
      locationMatch: 0.20,
      affordability: 0.15,
      suitability: 0.15,
      constraints: 0.15
    }
  },

  defaults: {
    location: "Nairobi",
    maxRecommendations: 5
  }
};
