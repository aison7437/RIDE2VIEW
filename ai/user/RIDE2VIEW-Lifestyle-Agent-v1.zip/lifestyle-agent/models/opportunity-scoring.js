function numeric(value, fallback = 0) {
  const n = Number(value);
  return Number.isFinite(n) ? n : fallback;
}

function scoreOne(item, context = {}) {
  const intent = context.intent || {};
  let intentMatch = numeric(item.reasoning?.intentScore, 0);
  let locationMatch = 0;
  let affordability = 50;
  let suitability = 50;
  let constraints = 50;

  if (context.location &&
      item.location &&
      String(context.location).toLowerCase() ===
      String(item.location).toLowerCase()) {
    locationMatch = 100;
  } else if (!context.location) {
    locationMatch = 75;
  }

  if (item.type === "property") {
    if (intent.budget !== null && intent.budget !== undefined) {
      const price = numeric(item.price);
      const budget = numeric(intent.budget);

      if (price <= budget) {
        affordability = 100;
      } else {
        const over = (price - budget) / Math.max(budget, 1);
        affordability = Math.max(0, 100 - over * 100);
      }
    } else if (intent.wantsAffordable) {
      affordability = Math.max(
        0,
        Math.min(100, 100 - numeric(item.price) / 3000)
      );
    }

    if (intent.maxViewingTime !== null &&
        intent.maxViewingTime !== undefined) {
      constraints =
        item.viewingMinutes <= intent.maxViewingTime ? 100 : 0;
    }

    suitability =
      50 +
      (intent.wantsStudent && item.studentFriendly ? 50 : 0) +
      (intent.wantsPremium && item.premium ? 50 : 0);

    if (intent.bedrooms !== null &&
        intent.bedrooms !== undefined &&
        item.bedrooms === intent.bedrooms) {
      suitability += 25;
    }

    suitability = Math.min(100, suitability);
  }

  if (item.type === "mobility") {
    if (intent.wantsWomenOnly) {
      constraints = item.womenOnly ? 100 : 0;
    }

    if (intent.wantsStudent) {
      suitability = item.studentFriendly ? 100 : 25;
    }

    if (intent.wantsPremium) {
      suitability = item.premium ? 100 : 25;
    }

    if (intent.wantsMobility) {
      intentMatch = Math.max(intentMatch, 70);
    }

    affordability = intent.wantsAffordable
      ? Math.max(0, 100 - numeric(item.price) / 20)
      : 75;
  }

  const total =
    intentMatch * 0.35 +
    locationMatch * 0.20 +
    affordability * 0.15 +
    suitability * 0.15 +
    constraints * 0.15;

  return {
    ...item,
    score: Math.round(total * 100) / 100,
    scoring: {
      intentMatch,
      locationMatch,
      affordability,
      suitability,
      constraints
    }
  };
}

function scoreOpportunities(opportunities = [], context = {}) {
  const list = Array.isArray(opportunities) ? opportunities : [];
  return list.map(item => scoreOne(item, context));
}

function rankOpportunities(opportunities = []) {
  const list = Array.isArray(opportunities) ? [...opportunities] : [];

  return list.sort((a, b) => {
    const scoreDiff = numeric(b.score) - numeric(a.score);
    if (scoreDiff !== 0) return scoreDiff;

    const aPrice = numeric(a.price, Number.MAX_SAFE_INTEGER);
    const bPrice = numeric(b.price, Number.MAX_SAFE_INTEGER);

    return aPrice - bPrice;
  });
}

module.exports = {
  scoreOpportunities,
  rankOpportunities,
  scoreOne
};
